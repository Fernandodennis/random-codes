<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="collection" tilewidth="320" tileheight="320" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="320" height="320" source="../images/hale_may_320.png"/>
 </tile>
 <tile id="2">
  <image width="96" height="32" source="../images/hex1.png"/>
 </tile>
 <tile id="3">
  <image width="184" height="184" source="../images/iso.png"/>
 </tile>
</tileset>
